package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- entities ---

@Entity(tableName = "shared_links")
data class SharedLink(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fileName: String,
    val fileSizeRaw: Long, // in bytes
    val fileType: String, // e.g. "application/json", "video/mp4", "image/png"
    val shareCode: String, // Unique share identifier, e.g., URL suffix
    val passwordProtected: Boolean,
    val passwordHash: String?, // Client-side simulated Argon2/SHA-256 hash
    val isOneTimeView: Boolean,
    val expiresAt: Long, // Epoch timestamp in ms
    val createdSec: Long = System.currentTimeMillis() / 1000,
    val downloadCount: Int = 0,
    val isRevoked: Boolean = false,
    val e2eeCiphertextSample: String, // Sample of encrypted base64 payload
    val e2eeKeyHash: String // Verification key hash of the hashed URL fragment key
)

@Entity(tableName = "session_logs")
data class SessionLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val deviceName: String,
    val location: String,
    val ipAddress: String,
    val lastActiveTime: Long = System.currentTimeMillis(),
    val isCurrentDevice: Boolean = false
)

@Entity(tableName = "user_config")
data class UserConfig(
    @PrimaryKey val id: Int = 1, // Single row configuration
    val username: String = "anonymous_cipher",
    val email: String = "uploader@secureshare.io",
    val isMfaEnabled: Boolean = false,
    val mfaSecret: String = "SSMFA777SECRETKEY",
    val usedStorageBytes: Long = 422 * 1024 * 1024, // Simulated default of 422MB used
    val totalStorageBytes: Long = 1024 * 1024 * 1024, // 1GB free tier limit
    val rememberMeToken: String? = null,
    val rememberMeEnabled: Boolean = false
)

// --- dao ---

@Dao
interface SecureShareDao {
    // Shared links queries
    @Query("SELECT * FROM shared_links ORDER BY id DESC")
    fun getAllSharedLinks(): Flow<List<SharedLink>>

    @Query("SELECT * FROM shared_links WHERE shareCode = :shareCode LIMIT 1")
    suspend fun getSharedLinkByCode(shareCode: String): SharedLink?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSharedLink(link: SharedLink): Long

    @Query("UPDATE shared_links SET downloadCount = downloadCount + 1 WHERE id = :id")
    suspend fun incrementDownloadCount(id: Int)

    @Query("UPDATE shared_links SET isRevoked = 1 WHERE id = :id")
    suspend fun revokeSharedLink(id: Int)

    @Query("DELETE FROM shared_links WHERE id = :id")
    suspend fun deleteSharedLink(id: Int)

    @Query("DELETE FROM shared_links")
    suspend fun clearAllLinks()

    // Session log queries
    @Query("SELECT * FROM session_logs ORDER BY lastActiveTime DESC")
    fun getAllSessionLogs(): Flow<List<SessionLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionLog(log: SessionLog): Long

    @Query("DELETE FROM session_logs WHERE id = :id")
    suspend fun deleteSessionLog(id: Int)

    @Query("DELETE FROM session_logs WHERE isCurrentDevice = 0")
    suspend fun terminateOtherSessions()

    // User config queries
    @Query("SELECT * FROM user_config WHERE id = 1 LIMIT 1")
    fun getUserConfigFlow(): Flow<UserConfig?>

    @Query("SELECT * FROM user_config WHERE id = 1 LIMIT 1")
    suspend fun getUserConfigDirect(): UserConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserConfig(config: UserConfig)
}

// --- database ---

@Database(
    entities = [SharedLink::class, SessionLog::class, UserConfig::class],
    version = 1,
    exportSchema = false
)
abstract class SecureShareDatabase : RoomDatabase() {
    abstract fun dao(): SecureShareDao
}
