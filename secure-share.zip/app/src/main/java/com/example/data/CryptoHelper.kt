package com.example.data

import android.util.Base64
import java.security.NoSuchAlgorithmException
import java.security.SecureRandom
import java.security.spec.InvalidKeySpecException
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object CryptoHelper {

    private const val PBKDF2_ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val AES_GCM_ALGORITHM = "AES/GCM/NoPadding"
    private const val ITERATIONS = 10000
    private const val KEY_LENGTH = 256
    private const val SALT_LENGTH = 16
    private const val IV_LENGTH = 12 // Standard for GCM
    private const val TAG_LENGTH_BITS = 128

    /**
     * Client-side strong hashing of passwords (simulating Argon2 / strong local proof)
     */
    fun hashPassword(password: String, saltBase64: String): String {
        try {
            val salt = Base64.decode(saltBase64, Base64.DEFAULT)
            val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
            val skf = SecretKeyFactory.getInstance(PBKDF2_ALGORITHM)
            val hash = skf.generateSecret(spec).encoded
            return Base64.encodeToString(hash, Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
            return password // Fallback if crypto fails
        }
    }

    /**
     * Generate a new cryptographically secure random salt
     */
    fun generateSalt(): String {
        val random = SecureRandom()
        val salt = ByteArray(SALT_LENGTH)
        random.nextBytes(salt)
        return Base64.encodeToString(salt, Base64.NO_WRAP)
    }

    /**
     * Generate a random AES key (to put in URL hash segment)
     */
    fun generateRandomKeyHex(): String {
        val random = SecureRandom()
        val keyBytes = ByteArray(32) // 256-bit key
        random.nextBytes(keyBytes)
        return keyBytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * Client-side E2EE AES-GCM-256 Encryption
     */
    fun encrypt(rawText: String, keyHex: String): String {
        return try {
            val keyBytes = hexToBytes(keyHex)
            val secretKey = SecretKeySpec(keyBytes, "AES")

            val random = SecureRandom()
            val iv = ByteArray(IV_LENGTH)
            random.nextBytes(iv)

            val cipher = Cipher.getInstance(AES_GCM_ALGORITHM)
            val spec = GCMParameterSpec(TAG_LENGTH_BITS, iv)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, spec)

            val ciphertext = cipher.doFinal(rawText.toByteArray(Charsets.UTF_8))

            // Prepend IV to ciphertext
            val combined = ByteArray(iv.size + ciphertext.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(ciphertext, 0, combined, iv.size, ciphertext.size)

            Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
            "ENCRYPTION_ERROR"
        }
    }

    /**
     * Client-side E2EE AES-GCM-256 Decryption
     */
    fun decrypt(combinedBase64: String, keyHex: String): String {
        return try {
            val keyBytes = hexToBytes(keyHex)
            val secretKey = SecretKeySpec(keyBytes, "AES")

            val combined = Base64.decode(combinedBase64, Base64.DEFAULT)
            if (combined.size < IV_LENGTH) {
                return "DECRYPTION_FAILED: Invalid package size"
            }

            val iv = ByteArray(IV_LENGTH)
            System.arraycopy(combined, 0, iv, 0, iv.size)

            val ciphertext = ByteArray(combined.size - IV_LENGTH)
            System.arraycopy(combined, iv.size, ciphertext, 0, ciphertext.size)

            val cipher = Cipher.getInstance(AES_GCM_ALGORITHM)
            val spec = GCMParameterSpec(TAG_LENGTH_BITS, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

            val decryptedBytes = cipher.doFinal(ciphertext)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            e.printStackTrace()
            "DECRYPTION_FAILED: Invalid key or password"
        }
    }

    private fun hexToBytes(hex: String): ByteArray {
        val len = hex.length
        val data = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            data[i / 2] = ((Character.digit(hex[i], 16) shl 4) + Character.digit(hex[i + 1], 16)).toByte()
            i += 2
        }
        return data
    }
}
