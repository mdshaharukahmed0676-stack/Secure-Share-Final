package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.util.UUID

class SecureShareRepository(private val dao: SecureShareDao) {

    val allSharedLinks: Flow<List<SharedLink>> = dao.getAllSharedLinks()
    val allSessionLogs: Flow<List<SessionLog>> = dao.getAllSessionLogs()
    val userConfigFlow: Flow<UserConfig?> = dao.getUserConfigFlow()

    suspend fun getSharedLink(shareCode: String): SharedLink? = dao.getSharedLinkByCode(shareCode)

    suspend fun createSharedLink(
        fileName: String,
        fileSizeRaw: Long,
        fileType: String,
        password: String?,
        isOneTimeView: Boolean,
        expiryHours: Int,
        rawPayload: String // We encrypt this locally before saving!
    ): String {
        // Generate a random 256-bit symmetric key that would reside only in URL hash fragment
        val decryptionKeyHex = CryptoHelper.generateRandomKeyHex()
        
        // Encrypt payload E2EE with the hex key
        val ciphertext = CryptoHelper.encrypt(rawPayload, decryptionKeyHex)
        
        // If password is supplied, passwordHash is generated
        val passwordHash = if (!password.isNullOrBlank()) {
            val salt = CryptoHelper.generateSalt()
            CryptoHelper.hashPassword(password, salt)
        } else {
            null
        }

        val shareCode = UUID.randomUUID().toString().substring(0, 8)
        val expiresAt = System.currentTimeMillis() + (expiryHours * 60 * 60 * 1000L)

        val link = SharedLink(
            fileName = fileName,
            fileSizeRaw = fileSizeRaw,
            fileType = fileType,
            shareCode = shareCode,
            passwordProtected = !password.isNullOrBlank(),
            passwordHash = passwordHash,
            isOneTimeView = isOneTimeView,
            expiresAt = expiresAt,
            e2eeCiphertextSample = ciphertext,
            e2eeKeyHash = CryptoHelper.hashPassword(decryptionKeyHex, "dec_salt_hash_ss")
        )

        dao.insertSharedLink(link)

        // Adjust simulated storage
        val currentConfig = dao.getUserConfigDirect() ?: UserConfig()
        val newStorage = currentConfig.usedStorageBytes + fileSizeRaw
        dao.saveUserConfig(currentConfig.copy(
            usedStorageBytes = newStorage.coerceAtMost(currentConfig.totalStorageBytes)
        ))

        // Return the combined link containing the shareCode AND the decryption key as a pseudo-hash-fragment:
        // secureshare.io/s/<shareCode>#<decryptionKeyHex>
        return "secureshare.io/s/$shareCode#$decryptionKeyHex"
    }

    suspend fun revokeLink(id: Int, fileSizeRaw: Long) {
        dao.revokeSharedLink(id)
        
        // Recover simulated storage space
        val currentConfig = dao.getUserConfigDirect() ?: UserConfig()
        val newStorage = (currentConfig.usedStorageBytes - fileSizeRaw).coerceAtLeast(0L)
        dao.saveUserConfig(currentConfig.copy(
            usedStorageBytes = newStorage
        ))
    }

    suspend fun deleteLink(id: Int, fileSizeRaw: Long) {
        dao.deleteSharedLink(id)
        // Recover simulated storage space
        val currentConfig = dao.getUserConfigDirect() ?: UserConfig()
        val newStorage = (currentConfig.usedStorageBytes - fileSizeRaw).coerceAtLeast(0L)
        dao.saveUserConfig(currentConfig.copy(
            usedStorageBytes = newStorage
        ))
    }

    suspend fun terminateOtherSessions() {
        dao.terminateOtherSessions()
    }

    suspend fun deleteSessionLog(id: Int) {
        dao.deleteSessionLog(id)
    }

    suspend fun updateUsername(newUsername: String, email: String) {
        val currentConfig = dao.getUserConfigDirect() ?: UserConfig()
        dao.saveUserConfig(currentConfig.copy(
            username = newUsername,
            email = email
        ))
    }

    suspend fun setMfaEnabled(enabled: Boolean) {
        val currentConfig = dao.getUserConfigDirect() ?: UserConfig()
        dao.saveUserConfig(currentConfig.copy(isMfaEnabled = enabled))
    }

    suspend fun saveRememberMe(enabled: Boolean, token: String? = null) {
        val currentConfig = dao.getUserConfigDirect() ?: UserConfig()
        dao.saveUserConfig(currentConfig.copy(
            rememberMeEnabled = enabled,
            rememberMeToken = token
        ))
    }

    /**
     * Seeds the local DB on run if config is empty.
     */
    suspend fun seedMockData() {
        // Seed default config
        val existingConfig = dao.getUserConfigDirect()
        if (existingConfig == null) {
            dao.saveUserConfig(UserConfig())
        }

        // Seed logs
        val existingLogs = dao.getAllSessionLogs().firstOrNull() ?: emptyList()
        if (existingLogs.isEmpty()) {
            dao.insertSessionLog(SessionLog(
                deviceName = "Android App Terminal (Pixel 8)",
                location = "San Francisco, USA",
                ipAddress = "192.168.1.144",
                isCurrentDevice = true
            ))
            dao.insertSessionLog(SessionLog(
                deviceName = "SafeShare Web App (Chrome macOS)",
                location = "Zurich, Switzerland",
                ipAddress = "82.165.12.98",
                isCurrentDevice = false
            ))
            dao.insertSessionLog(SessionLog(
                deviceName = "Secure Share Server-Side Daemon",
                location = "Tokyo, Japan",
                ipAddress = "210.140.10.45",
                isCurrentDevice = false
            ))
        }

        // Seed default time-limited demo links if empty
        val existingLinks = dao.getAllSharedLinks().firstOrNull() ?: emptyList()
        if (existingLinks.isEmpty()) {
            val key1 = CryptoHelper.generateRandomKeyHex()
            val ciphertext = CryptoHelper.encrypt("Confidential PDF details.", key1)
            dao.insertSharedLink(SharedLink(
                fileName = "financial_forecast_q3.pdf",
                fileSizeRaw = 12 * 1024 * 1024, // 12 MB
                fileType = "application/pdf",
                shareCode = "q3pdf101",
                passwordProtected = true,
                passwordHash = CryptoHelper.hashPassword("secret123", CryptoHelper.generateSalt()),
                isOneTimeView = false,
                expiresAt = System.currentTimeMillis() + (48 * 60 * 60 * 1000L),
                e2eeCiphertextSample = ciphertext,
                e2eeKeyHash = CryptoHelper.hashPassword(key1, "dec_salt_hash_ss"),
                downloadCount = 4
            ))

            val key2 = CryptoHelper.generateRandomKeyHex()
            val videoCiphertext = CryptoHelper.encrypt("Secure video payload bytes preview index", key2)
            dao.insertSharedLink(SharedLink(
                fileName = "leaked_product_keynotes.mp4",
                fileSizeRaw = 310 * 1024 * 1024, // 310 MB
                fileType = "video/mp4",
                shareCode = "keynote8",
                passwordProtected = false,
                passwordHash = null,
                isOneTimeView = true,
                expiresAt = System.currentTimeMillis() + (12 * 60 * 60 * 1000L),
                e2eeCiphertextSample = videoCiphertext,
                e2eeKeyHash = CryptoHelper.hashPassword(key2, "dec_salt_hash_ss"),
                downloadCount = 0
            ))
        }
    }
}
