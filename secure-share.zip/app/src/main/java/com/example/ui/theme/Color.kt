package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyberpunk Luxury Obsidian & Neon Purple Palette
val NeonPurple = Color(0xFFA855F7)
val DeepObsidian = Color(0xFF09090B)
val CardObsidian = Color(0xFF121215)
val LightGlass = Color(0x1AFFFDFD)
val GlowEmerald = Color(0xFF10B981)
val SleekGray = Color(0xFF2E2E33)
val BorderGlass = Color(0x33A855F7)

val AccentPurple = Color(0xFFD8B4FE)
val MutedText = Color(0xFF9CA3AF)
val ErrorRed = Color(0xFFEF4444)
