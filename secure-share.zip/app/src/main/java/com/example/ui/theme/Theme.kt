package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NeonPurple,
    onPrimary = Color.White,
    secondary = CardObsidian,
    onSecondary = Color.White,
    tertiary = GlowEmerald,
    onTertiary = Color.Black,
    background = DeepObsidian,
    onBackground = Color.White,
    surface = CardObsidian,
    onSurface = Color.White,
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark-mode themed interface
    dynamicColor: Boolean = false, // Keep exact luxury branding colors
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
