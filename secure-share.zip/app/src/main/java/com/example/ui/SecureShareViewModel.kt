package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface AuthState {
    object LoggedOut : AuthState
    data class MfaRequired(val username: String) : AuthState
    data class LoggedIn(val config: UserConfig) : AuthState
}

data class DecryptedVideoState(
    val isDecrypted: Boolean = false,
    val textChunks: List<String> = emptyList(), // On-the-fly decrypted frame blocks
    val currentChunkIndex: Int = 0,
    val error: String? = null
)

class SecureShareViewModel(application: Application) : AndroidViewModel(application) {

    // Initialize Room Database as a Singleton holder within application scope
    private val database: SecureShareDatabase by lazy {
        Room.databaseBuilder(
            application,
            SecureShareDatabase::class.java,
            "secure_share_db"
        ).fallbackToDestructiveMigration().build()
    }

    private val repository: SecureShareRepository by lazy {
        SecureShareRepository(database.dao())
    }

    // --- State Flows ---
    private val _authState = MutableStateFlow<AuthState>(AuthState.LoggedOut)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    val sharedLinks: StateFlow<List<SharedLink>> = repository.allSharedLinks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessionLogs: StateFlow<List<SessionLog>> = repository.allSessionLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userConfig: StateFlow<UserConfig?> = repository.userConfigFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Form inputs & UI responses
    var lastGeneratedUrl = MutableStateFlow<String?>(null)
    var isUploading = MutableStateFlow(false)
    var uploadErrorMessage = MutableStateFlow<String?>(null)
    
    // Video streaming engine simulator
    private val _videoState = MutableStateFlow(DecryptedVideoState())
    val videoState: StateFlow<DecryptedVideoState> = _videoState.asStateFlow()

    // Navigation payload holders
    var activePlayingLink: SharedLink? = null
    var activePlayingKeyHex: String? = null
    var activePlayingPassword: String? = null

    // Rate Limiting variables
    var loginAttempts = MutableStateFlow(0)
    var isBruteForceBlocked = MutableStateFlow(false)
    var lockoutCountdown = MutableStateFlow(0)

    init {
        viewModelScope.launch {
            repository.seedMockData()
            // Check if remember me token is present
            val config = repository.userConfigFlow.firstOrNull() ?: database.dao().getUserConfigDirect()
            if (config != null && config.rememberMeEnabled && !config.rememberMeToken.isNullOrBlank()) {
                _authState.value = AuthState.LoggedIn(config)
            }
        }
    }

    // --- Actions ---

    fun login(usernameOrEmail: String, password: String, rememberMe: Boolean): Boolean {
        if (isBruteForceBlocked.value) return false

        // Minimalist validation
        if (usernameOrEmail.isBlank() || password.isBlank()) {
            return false
        }

        // Simulating credential checking and standard rate limiting (Max 5 attempts)
        if (password == "admin_fail") {
            val currentAttempts = loginAttempts.value + 1
            loginAttempts.value = currentAttempts
            if (currentAttempts >= 5) {
                triggerLockout()
            }
            return false
        }

        // Clean user login routing
        val config = userConfig.value ?: UserConfig()
        if (config.isMfaEnabled) {
            _authState.value = AuthState.MfaRequired(config.username)
        } else {
            viewModelScope.launch {
                val token = if (rememberMe) "ROTATING_REFRESH_TOKEN_${UUID.randomUUID()}" else null
                repository.saveRememberMe(rememberMe, token)
                val refreshedConfig = database.dao().getUserConfigDirect() ?: config
                _authState.value = AuthState.LoggedIn(refreshedConfig)
            }
        }
        loginAttempts.value = 0 // Reset attempts on successful routing
        return true
    }

    fun verifyTotp(code: String): Boolean {
        // Simple mock OTP validation (accepts numeric codes matching '777')
        if (code.contains("123456") || code == "777777" || code == "777") {
            viewModelScope.launch {
                val config = database.dao().getUserConfigDirect() ?: UserConfig()
                _authState.value = AuthState.LoggedIn(config)
            }
            return true
        }
        return false
    }

    fun logout() {
        viewModelScope.launch {
            repository.saveRememberMe(false, null)
            _authState.value = AuthState.LoggedOut
        }
    }

    private fun triggerLockout() {
        isBruteForceBlocked.value = true
        lockoutCountdown.value = 30
        viewModelScope.launch {
            while (lockoutCountdown.value > 0) {
                kotlinx.coroutines.delay(1000)
                lockoutCountdown.value -= 1
            }
            isBruteForceBlocked.value = false
            loginAttempts.value = 0
        }
    }

    /**
     * E2EE Client-Side Upload Sequence:
     * Encrypts plaintext on device using AES-GCM prior to creating link.
     */
    fun performDeviceShare(
        fileName: String,
        fileSizeRaw: Long,
        fileType: String,
        password: String?,
        isOneTimeView: Boolean,
        expiryHours: Int,
        payloadPlaintext: String
    ) {
        if (payloadPlaintext.isBlank() || fileName.isBlank()) {
            uploadErrorMessage.value = "File payload contents and name cannot be empty."
            return
        }

        // Sandbox check for client-side pre-encryption validation (Simulate Malware Check)
        if (payloadPlaintext.contains("<script>") || payloadPlaintext.contains("eval(")) {
            uploadErrorMessage.value = "Malware Mitigation: Active scripts/executables blocked from encryption."
            return
        }

        viewModelScope.launch {
            isUploading.value = true
            uploadErrorMessage.value = null
            lastGeneratedUrl.value = null
            
            kotlinx.coroutines.delay(1200) // Simulated network upload latency

            try {
                val shareUrl = repository.createSharedLink(
                    fileName = fileName,
                    fileSizeRaw = fileSizeRaw,
                    fileType = fileType,
                    password = password,
                    isOneTimeView = isOneTimeView,
                    expiryHours = expiryHours,
                    rawPayload = payloadPlaintext
                )
                lastGeneratedUrl.value = shareUrl
            } catch (e: Exception) {
                uploadErrorMessage.value = "Encryption/Upload error: ${e.localizedMessage}"
            } finally {
                isUploading.value = false
            }
        }
    }

    fun revokeLink(link: SharedLink) {
        viewModelScope.launch {
            repository.revokeLink(link.id, link.fileSizeRaw)
        }
    }

    fun deleteLink(link: SharedLink) {
        viewModelScope.launch {
            repository.deleteLink(link.id, link.fileSizeRaw)
        }
    }

    fun updateSecuritySettings(newUsername: String, email: String, isMfaEnabled: Boolean) {
        viewModelScope.launch {
            repository.updateUsername(newUsername, email)
            repository.setMfaEnabled(isMfaEnabled)
        }
    }

    fun terminateAllOtherDevices() {
        viewModelScope.launch {
            repository.terminateOtherSessions()
        }
    }

    fun deleteSessionLog(id: Int) {
        viewModelScope.launch {
            repository.deleteSessionLog(id)
        }
    }

    // --- On-the-Fly Secure Video Stream Decryptor ---
    
    fun startVideoStreamingDecryption(link: SharedLink, passwordSubmitted: String?, keyHex: String?) {
        _videoState.value = DecryptedVideoState()

        if (keyHex.isNullOrBlank()) {
            _videoState.value = DecryptedVideoState(error = "Decryption key URL parameter missing.")
            return
        }

        // Verify password if protected
        if (link.passwordProtected) {
            val hashCheck = CryptoHelper.hashPassword(passwordSubmitted ?: "", CryptoHelper.generateSalt())
            // For mock verification, check if password hash exists
            if (passwordSubmitted.isNullOrBlank()) {
                _videoState.value = DecryptedVideoState(error = "Uploader password strictly required.")
                return
            }
        }

        viewModelScope.launch {
            // Decrypt the payload ciphertext in memory
            val rawPayload = CryptoHelper.decrypt(link.e2eeCiphertextSample, keyHex)

            if (rawPayload.startsWith("DECRYPTION_FAILED")) {
                _videoState.value = DecryptedVideoState(error = "Zero-Knowledge check failed: Invalid hash symmetric-key.")
                return@launch
            }

            // Successfully decrypted! Feed stream chunk-by-chunk in memory
            _videoState.value = DecryptedVideoState(isDecrypted = true)

            // Simulate parsing large high-resolution source video into on-the-fly chunks
            val mockChunks = listOf(
                "Streaming chunk 1: Buffer initialization (AES-GCM TLS layer verify)...",
                "Streaming chunk 2: Allocating 16MB system memory blocks - Decrypting byte slice 0-411...",
                "Streaming chunk 3: [Decrypted Video Stream Frame block 240-580p @ 30FPS active]",
                "Streaming chunk 4: [Decrypted Video Stream Frame block 580-920p @ 30FPS active]",
                "Streaming chunk 5: Rendering secured buffer layers on device hardware pipeline...",
                "Streaming chunk 6: Decrypted frame pipeline empty. Purging video cache memory."
            )

            for (index in mockChunks.indices) {
                if (_videoState.value.error != null) break
                _videoState.value = _videoState.value.copy(
                    textChunks = mockChunks.take(index + 1),
                    currentChunkIndex = index
                )
                kotlinx.coroutines.delay(1800) // Simulates chunk-level latency during dynamic playback
            }

            // Self-Destruct purging
            if (link.isOneTimeView) {
                deleteLink(link) // PURGE immediately from DB as soon as video streaming finishes!
            }
        }
    }

    fun clearVideoState() {
        _videoState.value = DecryptedVideoState()
    }
}
