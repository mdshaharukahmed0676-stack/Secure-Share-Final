package com.example.ui.screens

import android.app.Activity
import android.content.ContextWrapper
import android.view.WindowManager
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SharedLink
import com.example.ui.SecureShareViewModel
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.SubtleGlowCard
import com.example.ui.theme.*

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun VideoPlayerScreen(
    viewModel: SecureShareViewModel,
    selectedLink: SharedLink,
    decryptionKey: String,
    passwordSubmitted: String?,
    modifier: Modifier = Modifier,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val isWindowFocused = LocalWindowInfo.current.isWindowFocused

    // Extract MainActivity reference to set FLAG_SECURE
    val activity = remember(context) {
        var baseContext = context
        while (baseContext is ContextWrapper) {
            if (baseContext is Activity) {
                return@remember baseContext
            }
            baseContext = baseContext.baseContext
        }
        null
    }

    // MANDATORY Android Screen Capture prevention
    DisposableEffect(activity) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            viewModel.clearVideoState()
        }
    }

    val videoState by viewModel.videoState.collectAsState()

    // Trigger encryption stream compilation on mount
    LaunchedEffect(selectedLink, decryptionKey, passwordSubmitted) {
        viewModel.startVideoStreamingDecryption(selectedLink, passwordSubmitted, decryptionKey)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF210D3D), // top-left glowing purple accent block
                        DeepObsidian,      // solid core slate base
                        DeepObsidian
                    ),
                    center = androidx.compose.ui.geometry.Offset(200f, 150f),
                    radius = 1800f
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            
            // --- TOP NAVIGATION HEADER ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Exit Player", tint = Color.White)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Circle, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(8.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SECURED RECEIVER CHANNEL",
                        fontSize = 11.sp,
                        color = Color.LightGray,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }
            }

            // --- THE SHIELDED CUSTOM PLAYER CANVAS ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0F0F11))
                    .border(2.dp, Brush.radialGradient(listOf(NeonPurple, Color.Transparent)), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                // If app is blurred/backgrounded OR tab-switch occurs, instantly hide and blur content
                if (!isWindowFocused) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.DarkGray.copy(alpha = 0.92f))
                            .blur(30.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.VisibilityOff, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(11.dp))
                            Text(
                                "SCREEN CAPTURE SANITIZE TRIGGERED",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                "Video blurred as device environment integrity has toggled.",
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                        }
                    }
                } else {
                    // Normal state: Decrypt stream player timeline
                    when {
                        videoState.error != null -> {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(40.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = videoState.error!!,
                                    color = MaterialTheme.colorScheme.error,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 24.dp)
                                )
                            }
                        }
                        !videoState.isDecrypted -> {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = NeonPurple)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    "Acquiring decryption key block hashes...",
                                    color = Color.LightGray,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                        else -> {
                            // Video Active Playing Simulation with infinite pulse glow
                            val infiniteTransition = rememberInfiniteTransition(label = "player_glow")
                            val glowScale by infiniteTransition.animateFloat(
                                initialValue = 0.8f,
                                targetValue = 1.0f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(1200, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "scale"
                            )

                            Box(modifier = Modifier.fillMaxSize()) {
                                // Background matrix pattern
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(
                                                    Color.Black,
                                                    Color(0xFF1B0C27).copy(alpha = 0.5f)
                                                )
                                            )
                                        )
                                )

                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(16.dp),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // Simulated playback progress
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .background(GlowEmerald, RoundedCornerShape(4.dp))
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                "LIVE E2EE DEC STATE",
                                                fontSize = 10.sp,
                                                color = GlowEmerald,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }

                                        Text(
                                            "BUFFERING Chunks in Memory",
                                            fontSize = 10.sp,
                                            color = Color.LightGray.copy(alpha = 0.7f),
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    // Holographic play interface
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(1f)
                                            .wrapContentHeight(Alignment.CenterVertically)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.PlayCircleFilled,
                                            contentDescription = null,
                                            tint = GlowEmerald.copy(alpha = glowScale),
                                            modifier = Modifier.size(64.dp)
                                        )
                                        Spacer(modifier = Modifier.height(11.dp))
                                        Text(
                                            text = selectedLink.fileName,
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center
                                        )
                                        Text(
                                            text = "Rendering Secured Volatile Frames. No local storage active.",
                                            fontSize = 10.sp,
                                            color = Color.Gray,
                                            textAlign = TextAlign.Center
                                        )
                                    }

                                    // Locked Recorders warning banner info overlay
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color.Black.copy(alpha = 0.7f))
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.EnhancedEncryption, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Screenshots / recording software locked and blocked",
                                            fontSize = 9.sp,
                                            color = NeonPurple,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // --- ON INTERCEPTING CHUNK SPEC DEC TIMELINE PANEL ---
            GlassmorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(290.dp)
            ) {
                Text(
                    text = "Dynamic Memory Decryption Stream Trace",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Volatile byte decrypt logs. Blocks are discarded instantly from cache on render end.",
                    fontSize = 10.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                if (videoState.textChunks.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.3f))
                            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Awaiting secure cipher streaming data blocks...",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.3f))
                            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(videoState.textChunks.reversed()) { logChunk ->
                            Text(
                                text = "► $logChunk",
                                color = if (logChunk.contains("Frame block")) GlowEmerald else NeonPurple,
                                fontSize = 10.5.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
