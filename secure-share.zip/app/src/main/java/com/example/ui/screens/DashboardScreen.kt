package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.*
import com.example.ui.AuthState
import com.example.ui.SecureShareViewModel
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.SubtleGlowCard
import com.example.ui.theme.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import java.text.DecimalFormat

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: SecureShareViewModel,
    modifier: Modifier = Modifier,
    onNavigateToVideo: (SharedLink, String) -> Unit,
    onNavigateToLogin: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val authState by viewModel.authState.collectAsState()
    val sharedLinks by viewModel.sharedLinks.collectAsState()
    val sessionLogs by viewModel.sessionLogs.collectAsState()
    val userConfig by viewModel.userConfig.collectAsState()

    val isUploading by viewModel.isUploading.collectAsState()
    val lastGeneratedUrl by viewModel.lastGeneratedUrl.collectAsState()
    val uploadError by viewModel.uploadErrorMessage.collectAsState()

    // Dashboard navigation tabs: "Share Area" or "Device Control"
    var activeTabIndex by remember { mutableStateOf(0) }

    // Upload form local state
    var inputFileName by remember { mutableStateOf("") }
    var inputPayloadText by remember { mutableStateOf("") }
    var setPasswordChecked by remember { mutableStateOf(false) }
    var inputPasswordSecret by remember { mutableStateOf("") }
    var isOneTimeChecked by remember { mutableStateOf(false) }
    var inputExpiryHours by remember { mutableStateOf(12f) } // 12 hours default

    // User settings control edit state
    var editUsername by remember { mutableStateOf("") }
    var editEmail by remember { mutableStateOf("") }
    var editMfa by remember { mutableStateOf(false) }
    val showSettingsDialog = remember { mutableStateOf(false) }

    // Preset mock files helper to load templates
    val presetFiles = listOf(
        Triple("defense_contract_annex6.mp4", "Highly secure video frame telemetry recording bytes indices", "video/mp4"),
        Triple("database_secrets.json", "E2EE client configuration hash secrets: {\"id\": \"A23\"}", "application/json"),
        Triple("encrypted_voice.mp4", "Decrypted on-the-fly streaming speech bytes memo 120kbps", "video/mp4")
    )

    LaunchedEffect(userConfig) {
        userConfig?.let {
            editUsername = it.username
            editEmail = it.email
            editMfa = it.isMfaEnabled
        }
    }

    // Protection to assert logged-in state
    LaunchedEffect(authState) {
        if (authState is AuthState.LoggedOut) {
            onNavigateToLogin()
        }
    }

    val currentConfig = userConfig ?: com.example.data.UserConfig()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF210D3D), // top-left glowing purple accent block
                        DeepObsidian,      // solid core slate base
                        DeepObsidian
                    ),
                    center = androidx.compose.ui.geometry.Offset(200f, 150f),
                    radius = 1800f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            
            // --- TOP HEADER APP BAR (Sophisticated Dark Spec) ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(NeonPurple)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.EnhancedEncryption,
                            contentDescription = "Shield Lock",
                            tint = Color.White,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "SecureShare",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = (-0.3).sp
                        )
                        Text(
                            text = "ZERO-KNOWLEDGE ACTIVE",
                            fontSize = 9.sp,
                            color = GlowEmerald,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Profile button styled per Design HTML profile
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.05f))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                            .clickable { showSettingsDialog.value = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = "Profile Settings",
                            tint = Color.LightGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(10.dp))

                    IconButton(
                        onClick = { viewModel.logout() },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.05f))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Logout,
                            contentDescription = "Logout",
                            tint = Color.LightGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // --- STORAGE ESTIMATOR PROGRESS HEADER ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "Live Storage Utilization",
                        fontSize = 11.sp,
                        color = Color.LightGray.copy(alpha = 0.6f),
                        fontWeight = FontWeight.Bold
                    )
                    
                    val storagePercent = (currentConfig.usedStorageBytes.toFloat() / currentConfig.totalStorageBytes.toFloat()) * 100
                    Text(
                        text = "${formatBytes(currentConfig.usedStorageBytes)} / ${formatBytes(currentConfig.totalStorageBytes)} (${DecimalFormat("#.#").format(storagePercent)}%)",
                        fontSize = 11.sp,
                        color = NeonPurple,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                // Custom gradient bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White.copy(alpha = 0.1f))
                ) {
                    val percentFactor = (currentConfig.usedStorageBytes.toFloat() / currentConfig.totalStorageBytes.toFloat()).coerceIn(0f, 1f)
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(percentFactor)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(NeonPurple, GlowEmerald)
                                )
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // --- SEGMENT TABS ---
            TabRow(
                selectedTabIndex = activeTabIndex,
                containerColor = Color.Transparent,
                contentColor = NeonPurple,
                indicator = { tabPositions ->
                    TabRowDefaults.Indicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[activeTabIndex]),
                        color = NeonPurple
                    )
                },
                modifier = Modifier.padding(horizontal = 24.dp)
            ) {
                Tab(
                    selected = activeTabIndex == 0,
                    onClick = { activeTabIndex = 0 },
                    text = { Text("Upload & Share", fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = activeTabIndex == 1,
                    onClick = { activeTabIndex = 1 },
                    text = { Text("Security Center", fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // --- MAIN LIST / CONTENT ---
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (activeTabIndex == 0) {
                    // Upload Central Area
                    item {
                        GlassmorphicCard(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Zero-Knowledge Encryption Zone",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Files are encrypted client-side using robust AES-256-GCM. Decryption keys remain exclusively local.",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(bottom = 14.dp)
                            )

                            // Animated Mock Drag-and-Drop Area / Quick presets
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(
                                        width = 1.2.dp,
                                        brush = Brush.sweepGradient(listOf(NeonPurple, GlowEmerald)),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .background(Color.White.copy(alpha = 0.04f))
                                    .clickable {
                                        // Load random mock preset to easily demo sharing
                                        val randomPreset = presetFiles.random()
                                        inputFileName = randomPreset.first
                                        inputPayloadText = randomPreset.second
                                        Toast
                                            .makeText(
                                                context,
                                                "Secure Preset '${randomPreset.first}' selected!",
                                                Toast.LENGTH_SHORT
                                            )
                                            .show()
                                    }
                                    .padding(vertical = 24.dp, horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Outlined.CloudUpload,
                                        contentDescription = null,
                                        tint = GlowEmerald,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Click to load quick encrypted secure preset",
                                        fontSize = 12.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Or enter custom filename & payload below...",
                                        fontSize = 10.sp,
                                        color = Color.LightGray.copy(alpha = 0.5f)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Inputs
                            OutlinedTextField(
                                value = inputFileName,
                                onValueChange = { inputFileName = it },
                                label = { Text("Filename (e.g. security_memo.txt)") },
                                leadingIcon = { Icon(Icons.Filled.Description, contentDescription = null, tint = NeonPurple) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonPurple,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                ),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = inputPayloadText,
                                onValueChange = { inputPayloadText = it },
                                label = { Text("Private Payload Content / Stream payload") },
                                leadingIcon = { Icon(Icons.Filled.SecurityText, contentDescription = null, tint = NeonPurple) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonPurple,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                ),
                                placeholder = { Text("Enter highly private textual content to encrypt...") },
                                minLines = 2,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Custom Share Settings Block
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.clickable { setPasswordChecked = !setPasswordChecked }
                                ) {
                                    Checkbox(
                                        checked = setPasswordChecked,
                                        onCheckedChange = { setPasswordChecked = it },
                                        colors = CheckboxDefaults.colors(checkedColor = NeonPurple)
                                    )
                                    Text("Set Shared Password", fontSize = 12.sp, color = Color.White)
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.clickable { isOneTimeChecked = !isOneTimeChecked }
                                ) {
                                    Checkbox(
                                        checked = isOneTimeChecked,
                                        onCheckedChange = { isOneTimeChecked = it },
                                        colors = CheckboxDefaults.colors(checkedColor = GlowEmerald)
                                    )
                                    Text("Self-Destruct (One-Time View)", fontSize = 12.sp, color = GlowEmerald, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (setPasswordChecked) {
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = inputPasswordSecret,
                                    onValueChange = { inputPasswordSecret = it },
                                    label = { Text("Uploader Password Restriction") },
                                    leadingIcon = { Icon(Icons.Filled.Key, contentDescription = null, tint = NeonPurple) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NeonPurple,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedContainerColor = Color.Transparent,
                                        unfocusedContainerColor = Color.Transparent
                                    ),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Expiry Slider
                            Text(
                                text = "Sharing Expiry Limit: ${inputExpiryHours.toInt()} Hours",
                                fontSize = 12.sp,
                                color = Color.LightGray,
                                fontWeight = FontWeight.Bold
                            )
                            Slider(
                                value = inputExpiryHours,
                                onValueChange = { inputExpiryHours = it },
                                valueRange = 1f..72f,
                                colors = SliderDefaults.colors(
                                    thumbColor = NeonPurple,
                                    activeTrackColor = NeonPurple
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Action Button
                            if (isUploading) {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    LinearProgressIndicator(color = NeonPurple, modifier = Modifier.fillMaxWidth())
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Performing on-device crypt-hash AES-GCM-256...", fontSize = 11.sp, color = NeonPurple, fontFamily = FontFamily.Monospace)
                                }
                            } else {
                                Button(
                                    onClick = {
                                        viewModel.performDeviceShare(
                                            fileName = inputFileName,
                                            fileSizeRaw = inputPayloadText.length.toLong() * 1024, // Simulated size based on context length
                                            fileType = if (inputFileName.endsWith(".mp4")) "video/mp4" else "application/json",
                                            password = if (setPasswordChecked) inputPasswordSecret else null,
                                            isOneTimeView = isOneTimeChecked,
                                            expiryHours = inputExpiryHours.toInt(),
                                            payloadPlaintext = inputPayloadText
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Filled.Security, contentDescription = null, tint = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("ENCRYPT & DISPATCH SECURE LINK", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                                }
                            }

                            if (uploadError != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(uploadError!!, color = MaterialTheme.colorScheme.error, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            // Output result
                            lastGeneratedUrl?.let { url ->
                                Spacer(modifier = Modifier.height(14.dp))
                                SubtleGlowCard(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "Client Keyway Generated! Click payload to copy:",
                                        fontSize = 11.sp,
                                        color = GlowEmerald,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                clipboardManager.setText(AnnotatedString(url))
                                                Toast
                                                    .makeText(
                                                        context,
                                                        "Decryption URL link successfully copied to secure system paste buffer!",
                                                        Toast.LENGTH_SHORT
                                                    )
                                                    .show()
                                            }
                                            .background(Color.Black.copy(alpha = 0.4f))
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = url,
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            maxLines = 1,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(Icons.Filled.ContentCopy, contentDescription = "Copy", tint = NeonPurple, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }

                    // Active Links Table Header
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Active Share Ledger (${sharedLinks.size} Logs)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    if (sharedLinks.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No Active End-to-End Crypts Dispatching.", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }

                    // Feed lists active items
                    items(sharedLinks, key = { it.id }) { link ->
                        ActiveLinkCard(
                            link = link,
                            onRevoke = { viewModel.revokeLink(link) },
                            onDelete = { viewModel.deleteLink(link) },
                            onWatchVideo = { pass, key -> onNavigateToVideo(link, key) },
                            clipboardManager = clipboardManager,
                            context = context
                        )
                    }
                } else {
                    // Security Center tab configuration
                    item {
                        GlassmorphicCard(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Device Access Keys & MFA",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            // Username config
                            Text("Current Mask Username:", fontSize = 11.sp, color = Color.LightGray)
                            Text(currentConfig.username, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = NeonPurple, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(11.dp))

                            Text("Master Security Contact:", fontSize = 11.sp, color = Color.LightGray)
                            Text(currentConfig.email, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)

                            Spacer(modifier = Modifier.height(14.dp))

                            // MFA Switch Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Authenticator App MFA (TOTP)", fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("Force multi-layer shield checks on entry keys.", fontSize = 11.sp, color = Color.LightGray.copy(alpha = 0.6f))
                                }

                                Switch(
                                    checked = currentConfig.isMfaEnabled,
                                    onCheckedChange = { isChecked ->
                                        viewModel.updateSecuritySettings(
                                            newUsername = currentConfig.username,
                                            email = currentConfig.email,
                                            isMfaEnabled = isChecked
                                        )
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = GlowEmerald,
                                        checkedTrackColor = GlowEmerald.copy(alpha = 0.5f)
                                    )
                                )
                            }
                        }
                    }

                    // Active session logs header
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Hardware Active Session Logs",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Revoke All",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier
                                    .clickable { viewModel.terminateAllOtherDevices() }
                                    .padding(4.dp)
                            )
                        }
                    }

                    items(sessionLogs, key = { it.id }) { log ->
                        SubtleGlowCard(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (log.isCurrentDevice) Icons.Filled.Smartphone else Icons.Filled.Laptop,
                                        contentDescription = null,
                                        tint = if (log.isCurrentDevice) GlowEmerald else NeonPurple,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = log.deviceName + if (log.isCurrentDevice) " (This device)" else "",
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${log.ipAddress} • ${log.location}",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                if (!log.isCurrentDevice) {
                                    IconButton(onClick = { viewModel.deleteSessionLog(log.id) }) {
                                        Icon(Icons.Filled.Cancel, contentDescription = "Revoke Session", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(GlowEmerald.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("ACTIVE", color = GlowEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- DISPATCH CONFIG DIALOG ---
        if (showSettingsDialog.value) {
            AlertDialog(
                onDismissRequest = { showSettingsDialog.value = false },
                title = { Text("Client Mask Alignment", color = Color.White) },
                icon = { Icon(Icons.Filled.ManageAccounts, contentDescription = null, tint = NeonPurple) },
                text = {
                    Column {
                        Text("Edit your public identifier to mask real names on shared secure channels.", fontSize = 11.sp, color = Color.LightGray)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = editUsername,
                            onValueChange = { editUsername = it },
                            label = { Text("Display Username") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = NeonPurple,
                                focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                unfocusedContainerColor = Color.Black.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = editEmail,
                            onValueChange = { editEmail = it },
                            label = { Text("Notification Backup Email") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = NeonPurple,
                                focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                unfocusedContainerColor = Color.Black.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.updateSecuritySettings(editUsername, editEmail, editMfa)
                            showSettingsDialog.value = false
                        }
                    ) {
                        Text("COMMIT CHANGES", color = GlowEmerald, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showSettingsDialog.value = false }) {
                        Text("CANCEL", color = Color.Gray)
                    }
                },
                containerColor = CardObsidian,
                shape = RoundedCornerShape(16.dp)
            )
        }
    }
}

@Composable
fun ActiveLinkCard(
    link: SharedLink,
    onRevoke: () -> Unit,
    onDelete: () -> Unit,
    onWatchVideo: (String?, String) -> Unit,
    clipboardManager: androidx.compose.ui.platform.ClipboardManager,
    context: android.content.Context
) {
    var passwordUnlockInput by remember { mutableStateOf("") }
    var passwordRequiredOpen by remember { mutableStateOf(false) }

    // Derive simulated random URL decryption key to pass securely in copy link
    // E.g. secureshare.io/s/<shareCode>#<32-byte-hex-key>
    val mockDecryptionKeyHex = remember { CryptoHelper.generateRandomKeyHex() }
    val fullUrl = "secureshare.io/s/${link.shareCode}#$mockDecryptionKeyHex"

    SubtleGlowCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val fileIcon = if (link.fileType.startsWith("video/")) Icons.Filled.VideoFile else Icons.Filled.Article
                    Icon(
                        imageVector = fileIcon,
                        contentDescription = "File Type",
                        tint = if (link.isRevoked) Color.Gray else NeonPurple,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = link.fileName,
                            color = if (link.isRevoked) Color.Gray else Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            text = "${formatBytes(link.fileSizeRaw)} • ${link.fileType}",
                            fontSize = 11.sp,
                            color = Color.LightGray.copy(alpha = 0.5f)
                        )
                    }
                }

                // Delete/purge completely button
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Purge Link", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(11.dp))

            // State indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (link.isRevoked) {
                    Badge(containerColor = Color.DarkGray, contentColor = Color.LightGray) {
                        Text("REVOKED / OFFLINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(2.dp))
                    }
                } else if (System.currentTimeMillis() > link.expiresAt) {
                    Badge(containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.2f), contentColor = MaterialTheme.colorScheme.error) {
                        Text("EXPIRED", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(2.dp))
                    }
                } else {
                    Badge(containerColor = NeonPurple.copy(alpha = 0.15f), contentColor = NeonPurple) {
                        Text("E2EE SECURE ACTIVE", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(2.dp))
                    }
                }

                if (link.isOneTimeView) {
                    Badge(containerColor = GlowEmerald.copy(alpha = 0.15f), contentColor = GlowEmerald) {
                        Text("ONE-TIME VIEW ONLY", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(2.dp))
                    }
                } else {
                    Badge(containerColor = Color.White.copy(alpha = 0.05f), contentColor = Color.LightGray) {
                        Text("VIEWS: ${link.downloadCount}", fontSize = 10.sp, modifier = Modifier.padding(2.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Dynamic timing info & interactive buttons
            if (!link.isRevoked && System.currentTimeMillis() <= link.expiresAt) {
                val remainingMs = link.expiresAt - System.currentTimeMillis()
                val hrs = remainingMs / (1000L * 60 * 60)
                val mins = (remainingMs / (1000L * 60)) % 60
                
                Text(
                    text = "Expiry remaining: ${hrs}hrs ${mins}mins",
                    fontSize = 11.sp,
                    color = Color.LightGray,
                    fontWeight = FontWeight.Medium,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Copy secure URL
                    OutlinedButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(fullUrl))
                            Toast.makeText(context, "Copied decryption link!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(listOf(NeonPurple, GlowEmerald))
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("COPY CODE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // If file is secure Video, allow direct recepient streaming play
                    if (link.fileType.startsWith("video/")) {
                        Button(
                            onClick = {
                                if (link.passwordProtected) {
                                    passwordRequiredOpen = true
                                } else {
                                    onWatchVideo(null, mockDecryptionKeyHex)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GlowEmerald, contentColor = Color.Black),
                            modifier = Modifier.weight(1.2f)
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("WATCH STREAM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        // Regular revocation link
                        Button(
                            onClick = onRevoke,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("REVOKE SHARE", fontSize = 11.sp, color = Color.White)
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.History, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Encrypted segment sealed/purged history.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }

    // --- STREAM PASSWORD DISPATCH DIALOG ---
    if (passwordRequiredOpen) {
        AlertDialog(
            onDismissRequest = { passwordRequiredOpen = false },
            title = { Text("Stream Locked behind Uploader Password", color = Color.White) },
            icon = { Icon(Icons.Filled.Key, contentDescription = null, tint = NeonPurple) },
            text = {
                Column {
                    Text("The E2EE video segment payload requires both the hash URL key AND uploader verification code.", fontSize = 11.sp, color = Color.LightGray)
                    Spacer(modifier = Modifier.height(11.dp))
                    OutlinedTextField(
                        value = passwordUnlockInput,
                        onValueChange = { passwordUnlockInput = it },
                        label = { Text("Uploader Password") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = NeonPurple,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        passwordRequiredOpen = false
                        onWatchVideo(passwordUnlockInput, mockDecryptionKeyHex)
                    }
                ) {
                    Text("DECRYPT STREAM", color = GlowEmerald, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { passwordRequiredOpen = false }) {
                    Text("CANCEL", color = Color.Gray)
                }
            },
            containerColor = CardObsidian,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

// Convert bytes sizing safely
fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, digitGroups.toDouble())) + " " + units[digitGroups]
}

// Custom Icons for Text representation
val Icons.Filled.SecurityText: androidx.compose.ui.graphics.vector.ImageVector
    get() = Icons.Filled.DatasetLinked

val Icons.Filled.Pin: androidx.compose.ui.graphics.vector.ImageVector
    get() = Icons.Filled.Password
