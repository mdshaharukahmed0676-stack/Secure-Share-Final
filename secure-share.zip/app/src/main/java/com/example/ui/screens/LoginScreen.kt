package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.AuthState
import com.example.ui.SecureShareViewModel
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    viewModel: SecureShareViewModel,
    modifier: Modifier = Modifier,
    onLoginSuccess: () -> Unit
) {
    val authState by viewModel.authState.collectAsState()
    val isBlocked by viewModel.isBruteForceBlocked.collectAsState()
    val countdown by viewModel.lockoutCountdown.collectAsState()
    val focusManager = LocalFocusManager.current

    var usernameInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var passVisible by remember { mutableStateOf(false) }
    var rememberMeInput by remember { mutableStateOf(true) }
    
    var mfaCodeInput by remember { mutableStateOf("") }
    var showForgotDialog by remember { mutableStateOf(false) }
    var forgotSuccessMessage by remember { mutableStateOf<String?>(null) }
    var recoveryEmailInput by remember { mutableStateOf("") }

    var loginErrorMsg by remember { mutableStateOf<String?>(null) }
    var totpErrorMsg by remember { mutableStateOf<String?>(null) }

    // Stepper to handle animations
    val showMfa = authState is AuthState.MfaRequired

    // Handle instant success transition from state
    LaunchedEffect(authState) {
        if (authState is AuthState.LoggedIn) {
            onLoginSuccess()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF1E0E35), // subtle deep purple ambient bloom (top-left)
                        DeepObsidian,    // solid Sophisticated Dark base
                        DeepObsidian
                    ),
                    center = androidx.compose.ui.geometry.Offset(250f, 250f),
                    radius = 2200f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .statusBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            
            // --- HEADER (Sophisticated Dark Spec) ---
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(bottom = 28.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NeonPurple)
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.EnhancedEncryption,
                        contentDescription = "Shield Lock",
                        tint = Color.White,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "SecureShare",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = "ZERO-KNOWLEDGE ACTIVE",
                        fontSize = 10.sp,
                        color = GlowEmerald,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Check if user is locked out by Brute Force rate limiter
            if (isBlocked) {
                GlassmorphicCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Filled.Warning,
                        contentDescription = "Warning",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier
                            .size(48.dp)
                            .align(Alignment.CenterHorizontally)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Brute-Force Limit Triggered",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Your client IP has been temporarily secured from brute forcing. Please retry in:",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "${countdown}s",
                        color = NeonPurple,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            } else {
                // Animated view switcher between normal Login and MFA Totp
                AnimatedContent(
                    targetState = showMfa,
                    transitionSpec = {
                        slideInHorizontally { width -> width } + fadeIn() togetherWith
                                slideOutHorizontally { width -> -width } + fadeOut()
                    },
                    label = "LoginTransition"
                ) { isMfaNeeded ->
                    if (!isMfaNeeded) {
                        // --- GLASSMORPHIC CAPD: LOGIN CONTROLS ---
                        GlassmorphicCard(
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = "Access Keyway",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Enter credentials or authenticate with keys",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )

                            if (loginErrorMsg != null) {
                                Text(
                                    text = loginErrorMsg!!,
                                    color = MaterialTheme.colorScheme.error,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )
                            }

                            // --- Username input ---
                            OutlinedTextField(
                                value = usernameInput,
                                onValueChange = {
                                    usernameInput = it
                                    loginErrorMsg = null
                                },
                                label = { Text("Username or Security Email") },
                                leadingIcon = { Icon(Icons.Outlined.Person, contentDescription = null, tint = NeonPurple) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonPurple,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                    focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                    unfocusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // --- Password input ---
                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = {
                                    passwordInput = it
                                    loginErrorMsg = null
                                },
                                label = { Text("Uploader Password") },
                                leadingIcon = { Icon(Icons.Outlined.Key, contentDescription = null, tint = NeonPurple) },
                                trailingIcon = {
                                    IconButton(onClick = { passVisible = !passVisible }) {
                                        Icon(
                                            imageVector = if (passVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                            contentDescription = null,
                                            tint = Color.LightGray
                                        )
                                    }
                                },
                                visualTransformation = if (passVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonPurple,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                    focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                    unfocusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                supportingText = {
                                    if (passwordInput.isNotBlank() && passwordInput.length < 8) {
                                        Text("Strength: Weak (must be >= 8 chars)", color = MaterialTheme.colorScheme.error, fontSize = 10.sp)
                                    } else if (passwordInput.length >= 8) {
                                        Text("Strength: Strong Client Hash Active", color = GlowEmerald, fontSize = 10.sp)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                            
                            Spacer(modifier = Modifier.height(6.dp))

                            // --- Remember Me & Forgot Password ROW ---
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.clickable { rememberMeInput = !rememberMeInput }
                                ) {
                                    Checkbox(
                                        checked = rememberMeInput,
                                        onCheckedChange = { rememberMeInput = it },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = NeonPurple,
                                            uncheckedColor = Color.White.copy(alpha = 0.3f)
                                        )
                                    )
                                    Text(
                                        text = "Remember Me",
                                        color = Color.LightGray,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                Text(
                                    text = "Forgot Password?",
                                    color = NeonPurple,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .clickable {
                                            showForgotDialog = true
                                            forgotSuccessMessage = null
                                        }
                                        .padding(4.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            // --- SUBMIT ---
                            Button(
                                onClick = {
                                    focusManager.clearFocus()
                                    val success = viewModel.login(usernameInput, passwordInput, rememberMeInput)
                                    if (!success && !isBlocked) {
                                        loginErrorMsg = "Invalid username or key password authentication. (To trigger brute timeout, enter password: admin_fail)"
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonPurple,
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Filled.Lock, contentDescription = null, size = 16.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("DECRYPT PROFILE", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // WebAuthn Passkeys fallback mockup
                            OutlinedButton(
                                onClick = {
                                    // Simulated Passkey
                                    usernameInput = "anonymous_cipher"
                                    passwordInput = "password_gcm"
                                    viewModel.login("anonymous_cipher", "password_gcm", true)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color.White
                                ),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = Brush.horizontalGradient(listOf(NeonPurple, GlowEmerald))
                                )
                            ) {
                                Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = GlowEmerald)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("PASSKEY SECURE BYPASS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        // --- MFA TOTAL SCREEN ---
                        GlassmorphicCard(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                tint = GlowEmerald,
                                modifier = Modifier
                                    .size(48.dp)
                                    .align(Alignment.CenterHorizontally)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Two-Factor TOTP Key Required",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                text = "Authenticator protection is active. Please input the 6-digit verification code.",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )

                            if (totpErrorMsg != null) {
                                Text(
                                    text = totpErrorMsg!!,
                                    color = MaterialTheme.colorScheme.error,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )
                            }

                            OutlinedTextField(
                                value = mfaCodeInput,
                                onValueChange = {
                                    mfaCodeInput = it
                                    totpErrorMsg = null
                                },
                                label = { Text("6-Digit Code") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                leadingIcon = { Icon(Icons.Outlined.Pin, contentDescription = null, tint = GlowEmerald) },
                                placeholder = { Text("Hint: Type '777' or '777777'") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GlowEmerald,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                    focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                    unfocusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            Button(
                                onClick = {
                                    focusManager.clearFocus()
                                    val verified = viewModel.verifyTotp(mfaCodeInput)
                                    if (!verified) {
                                        totpErrorMsg = "Verification code fails checks."
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GlowEmerald,
                                    contentColor = Color.Black
                                )
                            ) {
                                Text("VERIFY & ACCESS", fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Cancel & Logout Link",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.logout() }
                                    .padding(8.dp)
                            )
                        }
                    }
                }
            }
        }

        // --- FORGOT PASSWORD DIALOG ---
        if (showForgotDialog) {
            AlertDialog(
                onDismissRequest = { showForgotDialog = false },
                title = { Text("Zero-Knowledge Password Recovery", color = Color.White) },
                icon = { Icon(Icons.Filled.Info, contentDescription = null, tint = NeonPurple) },
                text = {
                    Column {
                        Text(
                            text = "Because we are an E2EE Zero-Knowledge service, we do NOT store your decryption credentials. If you lose your master key, your encrypted payloads cannot be decrypted.\n\nHowever, entering your recovery security email allows rotating the key-pair using local metadata.",
                            fontSize = 11.sp,
                            color = Color.LightGray,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        OutlinedTextField(
                            value = recoveryEmailInput,
                            onValueChange = { recoveryEmailInput = it },
                            label = { Text("Security Email") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonPurple,
                                focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                unfocusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (forgotSuccessMessage != null) {
                            Text(
                                text = forgotSuccessMessage!!,
                                color = GlowEmerald,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            if (recoveryEmailInput.contains("@")) {
                                forgotSuccessMessage = "ROTATED: Recovery trigger dispatch sent. Reset token cached locally index 1."
                            } else {
                                forgotSuccessMessage = "Please insert a valid security email."
                            }
                        }
                    ) {
                        Text("DISPATCH", color = NeonPurple)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showForgotDialog = false }) {
                        Text("CLOSE", color = Color.Gray)
                    }
                },
                containerColor = CardObsidian,
                shape = RoundedCornerShape(16.dp)
            )
        }
    }
}

// Simple composable icon size parameter helper
@Composable
private fun Icon(
    imageVector: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String?,
    size: androidx.compose.ui.unit.Dp
) {
    Icon(
        imageVector = imageVector,
        contentDescription = contentDescription,
        tint = LocalContentColor.current,
        modifier = Modifier.size(size)
    )
}
