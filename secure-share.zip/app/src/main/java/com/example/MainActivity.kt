package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.SecureShareViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.VideoPlayerScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Initialize Viewmodel
                val mainViewModel: SecureShareViewModel = viewModel()
                val navController = rememberNavController()

                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "login",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        // 1. Password/MFA Entry Portal
                        composable("login") {
                            LoginScreen(
                                viewModel = mainViewModel,
                                modifier = Modifier.fillMaxSize(),
                                onLoginSuccess = {
                                    navController.navigate("dashboard") {
                                        popUpTo("login") { inclusive = true }
                                    }
                                }
                            )
                        }

                        // 2. High-performance Dashboard Control Area
                        composable("dashboard") {
                            DashboardScreen(
                                viewModel = mainViewModel,
                                modifier = Modifier.fillMaxSize(),
                                onNavigateToVideo = { link, key ->
                                    mainViewModel.activePlayingLink = link
                                    mainViewModel.activePlayingKeyHex = key
                                    mainViewModel.activePlayingPassword = if (link.passwordProtected) "verification_pass" else null
                                    
                                    navController.navigate("video_player")
                                },
                                onNavigateToLogin = {
                                    navController.navigate("login") {
                                        popUpTo("dashboard") { inclusive = true }
                                    }
                                }
                            )
                        }

                        // 3. Isolated Secure Receptor Stream Player Panel
                        composable("video_player") {
                            val activeLink = mainViewModel.activePlayingLink
                            val activeKeyHex = mainViewModel.activePlayingKeyHex
                            
                            if (activeLink != null && activeKeyHex != null) {
                                VideoPlayerScreen(
                                    viewModel = mainViewModel,
                                    selectedLink = activeLink,
                                    decryptionKey = activeKeyHex,
                                    passwordSubmitted = mainViewModel.activePlayingPassword,
                                    modifier = Modifier.fillMaxSize(),
                                    onBack = {
                                        navController.popBackStack()
                                    }
                                )
                            } else {
                                LaunchedEffect(Unit) {
                                    navController.popBackStack()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
